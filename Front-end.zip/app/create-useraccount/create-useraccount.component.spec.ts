import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateUseraccountComponent } from './create-useraccount.component';

describe('CreateUseraccountComponent', () => {
  let component: CreateUseraccountComponent;
  let fixture: ComponentFixture<CreateUseraccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateUseraccountComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateUseraccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
