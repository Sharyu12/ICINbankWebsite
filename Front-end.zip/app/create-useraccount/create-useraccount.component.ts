import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../useraccount';
import { UseraccountService } from '../useraccount.service';


@Component({
  selector: 'app-create-useraccount',
  templateUrl: './create-useraccount.component.html',
  styleUrls: ['./create-useraccount.component.css']
})
export class CreateUseraccountComponent implements OnInit {
  employee: Employee = new Employee();
  submitted = false;
  constructor(private useraccountService: UseraccountService, private router: Router) { }

  ngOnInit() {
  }
  newEmployee(): void {
    this.submitted = false;
    this.employee = new Employee();
  }

  save() {
    this.useraccountService.createEmployee(this.employee).subscribe(data => {
      console.log(data+" "+this.employee)
     this.employee = new Employee();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/employees']);
  }


}
