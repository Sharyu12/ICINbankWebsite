import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { CreateUserComponent } from './create-user/create-user.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { HomeComponent } from './home/home.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UserService } from './user.service';
import { OpenaccountComponent } from './openaccount/openaccount.component';
import {  CreateLoanrequestComponent } from './create-loanrequest/create-loanrequest.component';
import { LoanrequestListComponent } from './loanrequest-list/loanrequest-list.component';
import { TransactionreportComponent } from './transactionreport/transactionreport.component';
import { AdminComponent } from './admin/admin.component';
import { ChequeBookListComponent } from './cheque-book-list/cheque-book-list.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { CreateDepositComponent } from './create-deposit/create-deposit.component';
import {  CreateWithdrawComponent } from './create-withdraw/create-withdraw.component';
import {CreateRecipientComponent } from './create-recipient/create-recipient.component';
import {CreateChequeBookComponent } from './create-cheque-book/create-cheque-book.component';
import { LoanrequestService } from './loanrequest.service';
import { LoanrequestDetailsComponent } from './loanrequest-details/loanrequest-details.component';
import { UpdateLoanrequestComponent } from './update-loanrequest/update-loanrequest.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { FundTransactionListComponent } from './fund-transaction-list/fund-transaction-list.component';
import { RecipientListComponent } from './recipient-list/recipient-list.component';
import { UseraccountListComponent } from './useraccount-list/useraccount-list.component';
import { UseraccountDetailsComponent } from './useraccount-details/useraccount-details.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatIconModule } from '@angular/material/icon';
import { UpdateUseraccountComponent } from './update-useraccount/update-useraccount.component';
import { CreateFundTransactionComponent } from './create-fund-transaction/create-fund-transaction.component';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { AccountstatementComponent } from './accountstatement/accountstatement.component';
import { SavingaccountDetailsComponent } from './savingaccount-details/savingaccount-details.component';
import { SavingaccountListComponent } from './savingaccount-list/savingaccount-list.component';
import { PrimaryaccountListComponent } from './primaryaccount-list/primaryaccount-list.component';
import { PrimaryaccountDetailsComponent } from './primaryaccount-details/primaryaccount-details.component';
import { LoanlistComponent } from './loanlist/loanlist.component';
import { MyprofileListComponent } from './myprofile-list/myprofile-list.component';
import { MyprofileDetailsComponent } from './myprofile-details/myprofile-details.component';
import { UpdateMyprofileComponent } from './update-myprofile/update-myprofile.component';
@NgModule({
  declarations: [
    AppComponent,
    CreateUserComponent,
    UserloginComponent,
    HomeComponent,
    UserProfileComponent,
    OpenaccountComponent,
    LoanrequestListComponent,
    TransactionreportComponent,
      AdminComponent,
      ChequeBookListComponent,
      FundtransferComponent,
      AdminpageComponent,
      CreateDepositComponent,
      CreateWithdrawComponent,
      CreateRecipientComponent,
      LoanrequestDetailsComponent,
      CreateLoanrequestComponent,
      UpdateLoanrequestComponent,
      CreateChequeBookComponent,
      MyprofileComponent,
      FundTransactionListComponent,
      RecipientListComponent,
      UseraccountListComponent,
      UseraccountDetailsComponent,
      UpdateUseraccountComponent,
      CreateFundTransactionComponent,
      ContactComponent,
      AboutComponent,
      AccountstatementComponent,
      SavingaccountDetailsComponent,
      SavingaccountListComponent,
      PrimaryaccountListComponent,
      PrimaryaccountDetailsComponent,
      LoanlistComponent,
      MyprofileListComponent,
      MyprofileDetailsComponent,
      UpdateMyprofileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule,
    BrowserAnimationsModule,
    MatIconModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
