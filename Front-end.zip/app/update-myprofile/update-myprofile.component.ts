import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Myprofile } from '../myprofile';
import { MyprofileService } from '../myprofile.service';

@Component({
  selector: 'app-update-myprofile',
  templateUrl: './update-myprofile.component.html',
  styleUrls: ['./update-myprofile.component.css']
})
export class UpdateMyprofileComponent implements OnInit {
  id: number=0;
  myprofile: Myprofile=new Myprofile();
  constructor(private route: ActivatedRoute,private router: Router,
    private myprofileService: MyprofileService) { }

  ngOnInit() {
    this.myprofile = new Myprofile();

    this.id = this.route.snapshot.params['id'];
    
    this.myprofileService.getMyprofile(this.id)
      .subscribe(data => {
        console.log(data)
        this.myprofile = data;
      }, error => console.log(error));
  }

  updateMyprofile() {
    this.myprofileService.updateMyprofile(this.id, this.myprofile)
      .subscribe(data => {
        console.log(data);
        this.myprofile = new Myprofile();
        this.gotoList();
      }, error => console.log(error));
  }
  onSubmit() {
    this.updateMyprofile();    
  }
  gotoList() {
    this.router.navigate(['/myprofiles']);
  }
  }


