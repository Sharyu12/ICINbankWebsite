import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { deposit } from './deposit';
@Injectable({
  providedIn: 'root'
})
export class depositService {
    deposit(deposit: deposit) {
    throw new Error('Method not implemented.');
  }
 
 
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }

  getdeposit(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAlldeposit');
  }
  

  createdeposit(deposit: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/savedeposit', deposit);
  }

  

  


}
