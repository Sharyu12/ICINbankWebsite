import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Myprofile } from '../myprofile';
import { MyprofileService } from '../myprofile.service';

@Component({
  selector: 'app-myprofile-list',
  templateUrl: './myprofile-list.component.html',
  styleUrls: ['./myprofile-list.component.css']
})
export class MyprofileListComponent implements OnInit {
  myprofile: Observable<Myprofile[]>=new Observable;
  constructor(private myprofileService: MyprofileService,private router: Router) { }

  ngOnInit(): void {
    this.getMyprofiles();
  }
  getMyprofiles()
  {
    this.myprofile=this.myprofileService.getMyprofiles();
  }
  myprofileDetails(id: number){
    this.router.navigate(['mydetails', id]);
  }
  updateMyprofile(id: number)
  {
    this.router.navigate(['myupdate', id]);
  }
}
