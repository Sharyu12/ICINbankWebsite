import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateUserComponent } from './create-user/create-user.component';
import { HomeComponent } from './home/home.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { OpenaccountComponent } from './openaccount/openaccount.component';
import { LoanrequestListComponent } from './loanrequest-list/loanrequest-list.component';
import { UpdateLoanrequestComponent } from './update-loanrequest/update-loanrequest.component';
import { CreateLoanrequestComponent } from './create-loanrequest/create-loanrequest.component';
import { TransactionreportComponent } from './transactionreport/transactionreport.component';
import { AdminComponent } from './admin/admin.component';
import { FundTransactionListComponent } from './fund-transaction-list/fund-transaction-list.component';
import { ChequeBookListComponent } from './cheque-book-list/cheque-book-list.component';
import { CreateDepositComponent } from './create-deposit/create-deposit.component';
import {  CreateWithdrawComponent } from './create-withdraw/create-withdraw.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import {CreateRecipientComponent } from './create-recipient/create-recipient.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { CreateChequeBookComponent } from './create-cheque-book/create-cheque-book.component';
import { RecipientListComponent } from './recipient-list/recipient-list.component';
import { UseraccountListComponent } from './useraccount-list/useraccount-list.component';
import { UseraccountDetailsComponent } from './useraccount-details/useraccount-details.component';
import { UpdateUseraccountComponent } from './update-useraccount/update-useraccount.component';
import { CreateFundTransactionComponent } from './create-fund-transaction/create-fund-transaction.component';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { AccountstatementComponent } from './accountstatement/accountstatement.component';
import { SavingaccountDetailsComponent } from './savingaccount-details/savingaccount-details.component';
import { SavingaccountListComponent } from './savingaccount-list/savingaccount-list.component';
import { PrimaryaccountListComponent } from './primaryaccount-list/primaryaccount-list.component';
import { PrimaryaccountDetailsComponent } from './primaryaccount-details/primaryaccount-details.component';
import { LoanComponent } from './loan/loan.component';
import { LoanlistComponent } from './loanlist/loanlist.component';
import { MyprofileListComponent } from './myprofile-list/myprofile-list.component';
import { MyprofileDetailsComponent } from './myprofile-details/myprofile-details.component';
import { UpdateMyprofileComponent } from './update-myprofile/update-myprofile.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'add-user', component: CreateUserComponent },
  { path: 'userlogin', component:UserloginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'profile', component: UserProfileComponent },
  { path: 'openaccount', component: OpenaccountComponent  },
  { path: 'logout', redirectTo: 'home', pathMatch:'prefix' },
  { path: 'loanlist', component: CreateLoanrequestComponent  },
  { path: 'report', component: TransactionreportComponent  },
  { path: 'admin', component: AdminComponent  },
  { path: 'viewchequebooklist', component: ChequeBookListComponent },
  { path: 'addchequebook', component: CreateChequeBookComponent },
  { path: 'fundtransli', component: FundTransactionListComponent },
  { path: 'fundtransfo', component: FundtransferComponent  },
  { path: 'withdraw', component:CreateWithdrawComponent  },
  { path: 'deposit', component: CreateDepositComponent },
  { path: 'adminpage', component:  AdminpageComponent },
  { path: 'Recipient', component:  CreateRecipientComponent },
  { path: '', redirectTo: 'employees', pathMatch: 'full' },
  { path: 'employees', component: LoanrequestListComponent },
  { path: 'add', component: CreateLoanrequestComponent },
  { path: 'update/:id', component: UpdateLoanrequestComponent },
  { path: 'recipientli', component: RecipientListComponent },
  { path: 'useraccli', component: UseraccountListComponent },
  { path: 'useraccdet', component: UseraccountDetailsComponent },
  { path: 'details/:id', component: UseraccountDetailsComponent },
  { path: 'upuseracc', component: UpdateUseraccountComponent },
  { path: 'createfuntrans', component: CreateFundTransactionComponent },
  { path: 'contactus', component: ContactComponent },
  { path: 'aboutusdata', component: AboutComponent },
  { path: 'list', component: AccountstatementComponent },
  { path: 'savedetail/:id', component: SavingaccountDetailsComponent },
  { path: 'savelist', component: SavingaccountListComponent },
  { path: 'pridetail/:id', component: PrimaryaccountDetailsComponent },
  { path: 'prilist', component: PrimaryaccountListComponent },
  { path: 'loanlist', component: LoanlistComponent },
  { path: 'mydetails/:id', component: MyprofileDetailsComponent },
  { path: 'myupdate/:id', component: UpdateMyprofileComponent },
  { path: 'myprofiles', component: MyprofileListComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
