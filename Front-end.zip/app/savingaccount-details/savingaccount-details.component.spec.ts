import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SavingaccountDetailsComponent } from './savingaccount-details.component';

describe('SavingaccountDetailsComponent', () => {
  let component: SavingaccountDetailsComponent;
  let fixture: ComponentFixture<SavingaccountDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SavingaccountDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SavingaccountDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
