import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Savingaccount } from '../savingaccount';
import { SavingaccountService } from '../savingaccount.service';

@Component({
  selector: 'app-savingaccount-details',
  templateUrl: './savingaccount-details.component.html',
  styleUrls: ['./savingaccount-details.component.css']
})
export class SavingaccountDetailsComponent implements OnInit {
  id: number=0;
  savingaccount: Savingaccount=new Savingaccount();
  constructor(private route: ActivatedRoute,private router: Router,private savingaccountService: SavingaccountService) { }

  ngOnInit() {
    this.savingaccount = new Savingaccount();

    this.id = this.route.snapshot.params['id'];
    
    this.savingaccountService.getSavingaccount(this.id)
      .subscribe(data => {
        console.log(data)
        this.savingaccount = data;
      }, error => console.log(error));
      //this.list();
  }
  }


