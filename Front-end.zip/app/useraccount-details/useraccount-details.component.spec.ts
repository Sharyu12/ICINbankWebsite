import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UseraccountDetailsComponent } from './useraccount-details.component';

describe('UseraccountDetailsComponent', () => {
  let component: UseraccountDetailsComponent;
  let fixture: ComponentFixture<UseraccountDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UseraccountDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UseraccountDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
