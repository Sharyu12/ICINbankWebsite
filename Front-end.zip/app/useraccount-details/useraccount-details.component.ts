import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Useraccount } from '../useraccount';
import { UseraccountService } from '../useraccount.service';


@Component({
  selector: 'app-useraccount-details',
  templateUrl: './useraccount-details.component.html',
  styleUrls: ['./useraccount-details.component.css']
})
export class UseraccountDetailsComponent implements OnInit {
  id: number=0;
  useraccount: Useraccount=new Useraccount();
  constructor(private route: ActivatedRoute,private router: Router,private useraccountService: UseraccountService) { }

  ngOnInit() {
    this.useraccount = new Useraccount();

    this.id = this.route.snapshot.params['id'];
    
    this.useraccountService.getUseraccount(this.id)
      .subscribe(data => {
        console.log(data)
        this.useraccount = data;
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['employees']);
  }

  updateUseraccount(id: number)
  {
    this.router.navigate(['update', id]);
  }
  }


