import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {  Useraccount } from '../useraccount';
import { UseraccountService } from '../useraccount.service';


@Component({
  selector: 'app-update-useraccount',
  templateUrl: './update-useraccount.component.html',
  styleUrls: ['./update-useraccount.component.css']
})
export class UpdateUseraccountComponent implements OnInit {
  id: number=0;
  useraccount: Useraccount=new Useraccount();
  constructor(private route: ActivatedRoute,private router: Router,
    private useraccountService: UseraccountService) { }

  ngOnInit() {
    this.useraccount = new Useraccount();

    this.id = this.route.snapshot.params['id'];
    
    this.useraccountService.getUseraccount(this.id)
      .subscribe(data => {
        console.log(data)
        this.useraccount = data;
      }, error => console.log(error));
  }

  updateUseraccount() {
    this.useraccountService.updateUseraccount(this.id, this.useraccount)
      .subscribe(data => {
        console.log(data);
        this.useraccount = new Useraccount();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateUseraccount();    
  }

  gotoList() {
    this.router.navigate(['/employees']);
  }
  }


