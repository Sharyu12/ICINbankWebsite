import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateUseraccountComponent } from './update-useraccount.component';

describe('UpdateUseraccountComponent', () => {
  let component: UpdateUseraccountComponent;
  let fixture: ComponentFixture<UpdateUseraccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateUseraccountComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateUseraccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
