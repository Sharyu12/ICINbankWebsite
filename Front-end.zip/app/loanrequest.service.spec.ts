import { TestBed } from '@angular/core/testing';

import { LoanrequestService } from './loanrequest.service';

describe('LoanrequestService', () => {
  let service: LoanrequestService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoanrequestService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
