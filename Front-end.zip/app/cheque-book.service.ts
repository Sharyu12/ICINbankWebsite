import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { ChequeBook } from './cheque-book';
@Injectable({
  providedIn: 'root'
})
export class ChequeBookService {

  ChequeBook(ChequeBook: ChequeBook) {
    throw new Error('Method not implemented.');
  }
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }
  getchequebook(): Observable<any> {
  return this.http.get(`${this.baseUrl}`+'/getAllRequest');
}
createchequebook(ChequeBook: Object): Observable<Object> {
  return this.http.post(`${this.baseUrl}`+'/saveRequest', ChequeBook);
}
}
