import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class LoanrequestService {
 
 
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }

  getLoanrequests(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/Loanrequests');
  }
  getLoanrequest(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/Loanrequest/${id}`);
  }

  createLoanrequest(loanrequest: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/Loanrequest', loanrequest);
  }

  updateLoanrequest(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/Loanrequest/${id}`, value);
  }

  deleteLoanrequest(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/Loanrequest/${id}`, { responseType: 'text' });
  }


}
