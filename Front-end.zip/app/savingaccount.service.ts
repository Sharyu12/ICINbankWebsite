import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SavingaccountService {
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }
  getSavingaccounts(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllSavingaccount');
  }
  getSavingaccount(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/GET:/Savingaccount/${id}`);
  }
}
