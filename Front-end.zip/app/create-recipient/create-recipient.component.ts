import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Recipient } from '../recipient';
import { RecipientService } from '../recipient.service';

@Component({
  selector: 'app-create-recipient',
  templateUrl: './create-recipient.component.html',
  styleUrls: ['./create-recipient.component.css']
})
export class CreateRecipientComponent implements OnInit {
  recipient: Recipient= new Recipient();
  submitted = false;


  constructor(private recipientService: RecipientService, private router: Router) { }

  ngOnInit(): void {
    //this.getrecipient();
  }
  newrecipient(): void {
    this.submitted = false;
    this.recipient = new Recipient();
  }

  // private getrecipient(){
  //   this.recipientService.getrecipient().subscribe(data=>{this.recipient=data;});

  // }
  save() {
    
    this.recipientService.createrecipient(this.recipient).subscribe(data => {
      console.log(data+" "+this.recipient)
     this.recipient = new Recipient();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/recipient']);
  }
}
