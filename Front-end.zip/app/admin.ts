export class admin{
    
    u_name:string="";
    pwd:string="";
    
}