import { TestBed } from '@angular/core/testing';

import { depositService } from './deposit.service';

describe('depositService', () => {
  let service: depositService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(depositService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});