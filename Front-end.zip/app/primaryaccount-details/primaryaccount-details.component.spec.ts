import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimaryaccountDetailsComponent } from './primaryaccount-details.component';

describe('PrimaryaccountDetailsComponent', () => {
  let component: PrimaryaccountDetailsComponent;
  let fixture: ComponentFixture<PrimaryaccountDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrimaryaccountDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimaryaccountDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
