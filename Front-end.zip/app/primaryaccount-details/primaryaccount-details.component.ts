import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Primaryaccount } from '../primaryaccount';
import { PrimaryaccountService } from '../primaryaccount.service';

@Component({
  selector: 'app-primaryaccount-details',
  templateUrl: './primaryaccount-details.component.html',
  styleUrls: ['./primaryaccount-details.component.css']
})
export class PrimaryaccountDetailsComponent implements OnInit {

  id: number=0;
  primaryaccount: Primaryaccount=new Primaryaccount();
  constructor(private route: ActivatedRoute,private router: Router,private primaryaccountService: PrimaryaccountService) { }

  ngOnInit() {
    this.primaryaccount = new Primaryaccount();

    this.id = this.route.snapshot.params['id'];
    
    this.primaryaccountService.getPrimaryaccount(this.id)
      .subscribe(data => {
        console.log(data)
        this.primaryaccount = data;
      }, error => console.log(error));
      //this.list();
  }

}
