import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyprofileService {
  private baseUrl = 'http://localhost:8080/api/v1';
  constructor(private http: HttpClient) { }
  getMyprofiles(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllUseraccounts');
  }
  getMyprofile(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/Useraccount/${id}`);
  }
  updateMyprofile(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/Useraccount/${id}`, value);
  }
}
