import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl = 'http://localhost:8088/api/v1';

  constructor(private http: HttpClient) { }

  createUserRegistration(userregistration: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveUserRegistration',userregistration);
  }

  validateUserRegistration(user: Object): Observable<Object> {
    //alert("in service"+user);
    return this.http.post(`${this.baseUrl}/loginUserRegistration`, user);
  }
 
  isUserLoggedIn() {
    let user = sessionStorage.getItem("userName")
    if (user === null) return false
    return true
}
logout() {
  sessionStorage.removeItem("userName");
  sessionStorage.setItem("userlogin","failed");
  
}
getLoginStatus()
{
  const loginStatus=sessionStorage.getItem("userlogin");
  return loginStatus;
}
}
