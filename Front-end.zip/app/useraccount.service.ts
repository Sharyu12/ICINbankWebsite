import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UseraccountService {
  private baseUrl = 'http://localhost:8080/api/v1';
  constructor(private http: HttpClient) { }
  getUseraccounts(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/Useraccounts');
  }
  getUseraccount(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/Useraccount/${id}`);
  }

  createUseraccount(employee: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/Useraccount', employee);
  }

  updateUseraccount(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/Useraccount/${id}`, value);
  }

  deleteUseraccount(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/Useraccount/${id}`, { responseType: 'text' });
  }

}
