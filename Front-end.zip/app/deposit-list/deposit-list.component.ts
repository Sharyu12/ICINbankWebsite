import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { deposit} from '../deposit';
import { depositService } from '../deposit.service';

@Component({
  selector: 'app-deposit-list',
  templateUrl: './deposit-list.component.html',
  styleUrls: ['./deposit-list.component.css']
})
export class DepositListComponent implements OnInit {

  deposit: Observable<deposit[]>=new Observable;

  constructor(private depositService: depositService,private router: Router) {}
  
  ngOnInit(): void {
    this.getdeposit();
  }

  getdeposit()
  {
    this.deposit=this.depositService.getdeposit();
  }
  
  

  depositDetails(id: number){
    this.router.navigate(['details', id]);
  }
  
}
