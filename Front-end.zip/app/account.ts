export class Accountstatement{
    id: number=0;
    s_period: string="";
    a_no:number=0;
    date: string="";
    description:string=""; 
    withdraw: number=0;
    deposit: number=0;
    balance: number=0;
    ref: number=0;
   
}