import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanrequestDetailsComponent } from './loanrequest-details.component';

describe('LoanrequestDetailsComponent', () => {
  let component: LoanrequestDetailsComponent;
  let fixture: ComponentFixture<LoanrequestDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanrequestDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanrequestDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
