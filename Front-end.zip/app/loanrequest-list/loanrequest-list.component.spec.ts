import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanrequestListComponent } from './loanrequest-list.component';

describe('LoanrequestListComponent', () => {
  let component: LoanrequestListComponent;
  let fixture: ComponentFixture<LoanrequestListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanrequestListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanrequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
