import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import {  Loanrequest } from '../loanrequest';
import {  LoanrequestService } from '../loanrequest.service';
@Component({
  selector: 'app-loanrequest-list',
  templateUrl: './loanrequest-list.component.html',
  styleUrls: ['./loanrequest-list.component.css']
})
export class LoanrequestListComponent implements OnInit {
  loanrequest: Observable<Loanrequest[]>=new Observable;
  constructor(private loanrequestService: LoanrequestService,private router: Router) { }

  ngOnInit(): void {
    this.getLoanrequests();
  }

  getLoanrequests()
  {
    this.loanrequest=this.loanrequestService.getLoanrequests();
  }
  deleteLoanrequest(id: number) {
    this.loanrequestService.deleteLoanrequest(id)
      .subscribe(
        data => {
          console.log(data);
          this.getLoanrequests();
        },
        error => console.log(error));
  }

  loanrequestDetails(id: number){
    this.router.navigate(['details', id]);
  }
  updateLoanrequest(id: number)
  {
    this.router.navigate(['update', id]);
  }
}

  


