import { TestBed } from '@angular/core/testing';

import { withdrawService } from './withdraw.service';

describe('withdrawService', () => {
  let service: withdrawService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(withdrawService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
