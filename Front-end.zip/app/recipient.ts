export class Recipient {
    s_no:number=0;
    a_name:string="";
     email:string=""; 
     phone:number=0;
     p_ac:number=0;
     s_ac:number=0;
    description:string="";
}
