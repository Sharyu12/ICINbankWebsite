import { TestBed } from '@angular/core/testing';

import { SavingaccountService } from './savingaccount.service';

describe('SavingaccountService', () => {
  let service: SavingaccountService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SavingaccountService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
