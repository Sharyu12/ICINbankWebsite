export class Primaryaccount{
   
        id:number=0;
        name:string="";
        address:string="";
        date:string="";
        phone: number=0;
        a_NO: number=0;
        b_CODE: number=0;
        mir_CODE: number=0;
        b_NAME: string="";
        b_ADDRESS: string="";
        ifsc_CODE: number=0;
    }
