import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyprofileDetailsComponent } from './myprofile-details.component';

describe('MyprofileDetailsComponent', () => {
  let component: MyprofileDetailsComponent;
  let fixture: ComponentFixture<MyprofileDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyprofileDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyprofileDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
