import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Myprofile } from '../myprofile';
import { MyprofileService } from '../myprofile.service';

@Component({
  selector: 'app-myprofile-details',
  templateUrl: './myprofile-details.component.html',
  styleUrls: ['./myprofile-details.component.css']
})
export class MyprofileDetailsComponent implements OnInit {
  id: number=0;
  myprofile: Myprofile=new Myprofile();
  constructor(private route: ActivatedRoute,private router: Router,private myprofileService: MyprofileService) { }

  ngOnInit() {
    this.myprofile = new Myprofile();

    this.id = this.route.snapshot.params['id'];
    
    this.myprofileService.getMyprofile(this.id)
      .subscribe(data => {
        console.log(data)
        this.myprofile = data;
      }, error => console.log(error));
      //this.list();
  }
  updateMyprofile() {
    this.myprofileService.updateMyprofile(this.id, this.myprofile)
      .subscribe(data => {
        console.log(data);
        this.myprofile = new Myprofile();
        this.gotoList();
      }, error => console.log(error));
  }
  gotoList() {
    this.router.navigate(['/myprofiles']);
  }
  list(){
    this.router.navigate(['/myprofiles']);
  }
  }


