import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PrimaryaccountService {
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }
  getPrimaryaccounts(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllPrimaryaccount');
  }
  getPrimaryaccount(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/GET:/Primaryaccount/${id}`);
  }
}
