import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { deposit } from '../deposit';
import { depositService } from '../deposit.service';

@Component({
  selector: 'app-create-deposit',
  templateUrl: './create-deposit.component.html',
  styleUrls: ['./create-deposit.component.css']
})
export class CreateDepositComponent implements OnInit {

  deposit: deposit = new deposit();
  submitted = false;

  constructor(private depositService: depositService, private router: Router) { }

  ngOnInit() {
  }

  newdeposit(): void {
    this.submitted = false;
    this.deposit = new deposit();
  }

  save() {
    this.depositService.createdeposit(this.deposit).subscribe(data => {
      console.log(data+" "+this.deposit)
     this.deposit = new deposit();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/deposit']);
  }


}
