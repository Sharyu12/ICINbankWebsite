import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ChequeBook } from '../cheque-book';
import { ChequeBookService } from '../cheque-book.service';

@Component({
  selector: 'app-create-cheque-book',
  templateUrl: './create-cheque-book.component.html',
  styleUrls: ['./create-cheque-book.component.css']
})
export class CreateChequeBookComponent implements OnInit {

  ChequeBook: ChequeBook= new ChequeBook();
  submitted = false;


  constructor(private ChequeBookService: ChequeBookService, private router: Router) { }

  ngOnInit(): void {
    //this.getrecipient();
  }
  newchequebook(): void {
    this.submitted = false;
    this.ChequeBook = new ChequeBook();
  }

  // private getrecipient(){
  //   this.recipientService.getrecipient().subscribe(data=>{this.recipient=data;});

  // }
  saveChequeBook() {
    
    this.ChequeBookService.createchequebook(this.ChequeBook).subscribe(data => {
      console.log(data+" "+this.ChequeBook)
     this.ChequeBook = new ChequeBook();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.saveChequeBook();    
  }

  gotoList() {
    this.router.navigate(['/cheque-book']);
  }

}
