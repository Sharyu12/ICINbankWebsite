import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { FundTransaction} from '../fund-transaction';
import { FundTransactionService } from '../fund-transaction.service';

@Component({
  selector: 'app-fund-transaction-list',
  templateUrl:'./fund-transaction-list.component.html',
  styleUrls: ['./fund-transaction-list.component.css']
})
export class FundTransactionListComponent implements OnInit {

  fundTransaction: Observable<FundTransaction[]>=new Observable;
  constructor(private FundTransactionService:FundTransactionService,private router: Router) { }

  ngOnInit(): void {
    this.getfundTransaction();
  }
  getfundTransaction()
  {
    this.fundTransaction=this.FundTransactionService.getfundTransaction();
  }
  
  

  fundTransactionDetails(a_no: number){
    this.router.navigate(['details', a_no]);
  }

}
