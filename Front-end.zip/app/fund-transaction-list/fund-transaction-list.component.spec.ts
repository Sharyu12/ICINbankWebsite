import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FundTransactionListComponent } from './fund-transaction-list.component';

describe('FundTransactionListComponent', () => {
  let component: FundTransactionListComponent;
  let fixture: ComponentFixture<FundTransactionListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FundTransactionListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FundTransactionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
