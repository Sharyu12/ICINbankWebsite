import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { Recipient } from './recipient';

@Injectable({
  providedIn: 'root'
})

export class RecipientService {

  Recipient(Recipient: Recipient) {
    throw new Error('Method not implemented.');
  }
  private baseUrl = 'http://localhost:8088/api/v1';

  constructor(private http: HttpClient) { }
  getrecipient(): Observable<any> {
  return this.http.get(`${this.baseUrl}`+'/getAllRecipient');
}
createrecipient(Recipient: Object): Observable<Object> {
  return this.http.post(`${this.baseUrl}`+'/saveRecipient', Recipient);
}
}

