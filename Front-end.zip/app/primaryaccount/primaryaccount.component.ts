import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primaryaccount',
  templateUrl: './primaryaccount.component.html',
  styleUrls: ['./primaryaccount.component.css']
})
export class PrimaryaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
