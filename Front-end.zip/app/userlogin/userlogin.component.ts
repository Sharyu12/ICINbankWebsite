import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserRegistration } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  user: UserRegistration = new UserRegistration();
  submitted = false;
  message!: string;
  hasLoginFailed!: boolean;

  ngOnInit(): void {
  }

  newUser(): void {
    this.submitted = false;
    this.user = new UserRegistration();
  }

  constructor(private userService: UserService, private router: Router) { }

  onSubmit() {
    this.submitted = true;
    this.validate();    
  }

  validate() {
     //alert(this.user.userName);
     this.userService.validateUserRegistration(this.user).subscribe(data => {
    
      //console.log(data+" "+this.user)
     if(data!=null)
     {
     
     this.router.navigate(['/profile']);
     sessionStorage.setItem("userName", this.user.userName);
     sessionStorage.setItem("name", this.user.userName);
     sessionStorage.setItem("userlogin","success");
     this.hasLoginFailed=false;
     }
     else
    {
    this.router.navigate(['/userlogin']);
    this.message="Invalid Credentials....Try again!";
    this.hasLoginFailed=true;
    sessionStorage.setItem("userlogin","failed");
    this.user = new UserRegistration();
    }
    },
   error => console.log(error)
   
   );
  }

}
