import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-openaccount',
  templateUrl: './openaccount.component.html',
  styleUrls: ['./openaccount.component.css']
})
export class OpenaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
