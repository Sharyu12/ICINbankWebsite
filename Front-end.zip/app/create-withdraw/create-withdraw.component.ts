import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { withdraw } from '../withdraw';
import { withdrawService } from '../withdraw.service';

@Component({
  selector: 'app-create-withdraw',
  templateUrl: './create-withdraw.component.html',
  styleUrls: ['./create-withdraw.component.css']
})
export class CreateWithdrawComponent implements OnInit {

  withdraw: withdraw = new withdraw();
  submitted = false;

  constructor(private withdrawService: withdrawService, private router: Router) { }

  ngOnInit() {
  }

  newwithdraw(): void {
    this.submitted = false;
    this.withdraw = new withdraw();
  }

  save() {
    this.withdrawService.createwithdraw(this.withdraw).subscribe(data => {
      console.log(data+" "+this.withdraw)
     this.withdraw = new withdraw();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/withdraw']);
  }


}
