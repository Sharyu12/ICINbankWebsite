export class deposit{
    
    account_no:number=0;
    account_title:string="";
    amount:number=0;
    delivering_institution:string="";
    deposit_date:number=0;
    transaction_id:number=0;

}