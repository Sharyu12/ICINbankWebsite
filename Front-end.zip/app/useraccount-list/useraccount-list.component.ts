import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import {  Useraccount } from '../useraccount';
import { UseraccountService } from '../useraccount.service';


@Component({
  selector: 'app-useraccount-list',
  templateUrl: './useraccount-list.component.html',
  styleUrls: ['./useraccount-list.component.css']
})
export class UseraccountListComponent implements OnInit {
  useraccount: Observable<Useraccount[]>=new Observable;

  constructor(private useraccountService: UseraccountService,private router: Router) { }

  ngOnInit(): void {
    this.getUseraccounts();
  }
  getUseraccounts()
  {
    this.useraccount=this.useraccountService.getUseraccounts();
  }
  
  deleteUseraccount(id: number) {
    this.useraccountService.deleteUseraccount(id)
      .subscribe(
        data => {
          console.log(data);
          this.getUseraccounts();
        },
        error => console.log(error));
  }

  useraccountDetails(id: number){
    this.router.navigate(['details', id]);
  }
  updateUseraccount(id: number)
  {
    this.router.navigate(['update', id]);
  }
}
