import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UseraccountListComponent } from './useraccount-list.component';

describe('UseraccountListComponent', () => {
  let component: UseraccountListComponent;
  let fixture: ComponentFixture<UseraccountListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UseraccountListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UseraccountListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
