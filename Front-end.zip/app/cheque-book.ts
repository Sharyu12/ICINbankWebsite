export class ChequeBook {
    s_no:number=0;
    a_type:string="";
    description:string ="";
    u_name:string=""

}

