import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { Accountstatement } from '../accountstatement';
import { AccountstatementService } from '../accountstatement.service';

@Component({
  selector: 'app-accountstatement',
  templateUrl: './accountstatement.component.html',
  styleUrls: ['./accountstatement.component.css']
})
export class AccountstatementComponent implements OnInit {
  accountstatement: Observable<Accountstatement[]>=new Observable;
  constructor(private accountstatementService: AccountstatementService,private router: Router) { }

  ngOnInit(): void {
    this. getAccountstatement();
  }
  getAccountstatement()
  {
    this.accountstatement=this.accountstatementService. getAccountstatement();
  }
  
}
