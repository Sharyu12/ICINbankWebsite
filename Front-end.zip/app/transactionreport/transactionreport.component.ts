import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transactionreport',
  templateUrl: './transactionreport.component.html',
  styleUrls: ['./transactionreport.component.css']
})
export class TransactionreportComponent implements OnInit {
  transactionData :any | undefined;
    
  constructor(/*private transactionService:TransactionService */) { }

  ngOnInit(): void {
     /* this.transactionService.getAllTransactions().subscribe((allData)=>
      {
        this.transactionData = allData ;
      }); */
  }

}
