import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserRegistration } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  userregistration: UserRegistration = new UserRegistration();
  submitted = false;

  constructor(private userService: UserService,private router: Router) { }

  ngOnInit(): void {
  }

  newUserRegistration(): void {
    this.submitted = false;
    this.userregistration = new UserRegistration();
  }

  save() {
    this.userService.createUserRegistration(this.userregistration).subscribe(data => {
      console.log(data+" "+this.userregistration)
     this.userregistration = new UserRegistration();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();
    alert(" REGISTRATION IS COMPLETED CLICK LOGIN TO CONTINUE");
    this.router.navigate(['/userregistration']);    
  }

  gotoList() {
    this.router.navigate(['/userregistration']);
  }


}
