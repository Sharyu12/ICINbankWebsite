
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { FundTransaction } from './fund-transaction';

@Injectable({
  providedIn: 'root'
})
export class FundTransactionService {
  FundTransaction(FundTransaction:FundTransaction) {
    throw new Error('Method not implemented.');
  }
  private baseUrl = 'http://localhost:8088/api/v1';
  
  constructor(private http: HttpClient) { }
  getfundTransaction(): Observable<any> {
  return this.http.get(`${this.baseUrl}`+'/getAllFundtransfer');
}
createfundTransaction(FundTransaction: Object): Observable<Object> {
  return this.http.post(`${this.baseUrl}`+'/saveFundtransfer', FundTransaction);
}
}
