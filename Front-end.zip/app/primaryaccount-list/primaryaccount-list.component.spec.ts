import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimaryaccountListComponent } from './primaryaccount-list.component';

describe('PrimaryaccountListComponent', () => {
  let component: PrimaryaccountListComponent;
  let fixture: ComponentFixture<PrimaryaccountListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrimaryaccountListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimaryaccountListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
