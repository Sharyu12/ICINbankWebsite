import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Primaryaccount } from '../primaryaccount';
import { PrimaryaccountService } from '../primaryaccount.service';

@Component({
  selector: 'app-primaryaccount-list',
  templateUrl: './primaryaccount-list.component.html',
  styleUrls: ['./primaryaccount-list.component.css']
})
export class PrimaryaccountListComponent implements OnInit {

  primaryaccount: Observable<Primaryaccount[]>=new Observable;
  constructor(private primaryaccountService: PrimaryaccountService,private router: Router) { }

  ngOnInit(): void {
    this.getSavingaccounts();
  }
  getSavingaccounts()
  {
    this.primaryaccount=this.primaryaccountService.getPrimaryaccounts();
  }
  primaryaccountDetails(id: number){
    this.router.navigate(['pridetail', id]);
  }
}


