export class Loanrequest{
    id:number=0;
    name:string="";
    a_no:string="";
    address:string="";
    designation:string="";
    emailId:string="";
    gender:string="";
    loanamount:number=0;
    loantype:string="";
    netsalary:number=0;
    phone:number=0;
}