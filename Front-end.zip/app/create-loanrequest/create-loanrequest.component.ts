import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Loanrequest } from '../loanrequest';
import { LoanrequestService } from '../loanrequest.service';
@Component({
  selector: 'app-create-loanrequest',
  templateUrl: './create-loanrequest.component.html',
  styleUrls: ['./create-loanrequest.component.css']
})
export class CreateLoanrequestComponent implements OnInit {
  loanrequest: Loanrequest= new Loanrequest();
  submitted = false;
  constructor(private loanrequestService: LoanrequestService, private router: Router) { }

  ngOnInit(): void {
  }
  newLoanrequest(): void {
    this.submitted = false;
    this.loanrequest = new Loanrequest();
  }

  save() {
    this.loanrequestService.createLoanrequest(this.loanrequest).subscribe(data => {
      console.log(data+" "+this.loanrequest)
     this.loanrequest = new Loanrequest();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/employees']);
  }

}
