export class Loan{
    name: string="";
        email: string="";
        phone: number=0;
        gender: string="";
        address: string="";
        designation: string="";
        id: number=0;
        a_No: number=0;
        net_salary: number=0;
        loan_Amount: number=0;
}