import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { withdraw } from './withdraw';
@Injectable({
  providedIn: 'root'
})
export class withdrawService {
    withdraw(withdraw: withdraw) {
    throw new Error('Method not implemented.');
  }
 
 
  private baseUrl = 'http://localhost:8088/api/v1';

  constructor(private http: HttpClient) { }

  getwithdraw(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllwithdraw');
  }
  

  createwithdraw(withdraw: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/savewithdraw', withdraw);
  }

}
