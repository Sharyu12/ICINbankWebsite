export class UserRegistration{
    userid:number=0;
    firstName:string="";
    lastName:string="";
    phonenum:number=0;
    emailId:string="";
    userName:string='';
    password:string='';
}