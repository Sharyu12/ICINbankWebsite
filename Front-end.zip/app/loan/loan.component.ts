import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LoanService } from '../loan.service';
import { Loan } from '../loan';
@Component({
  selector: 'app-loanrequest-list',
  templateUrl: './loan.component.html',
  styleUrls: ['./loan.component.css']
})
export class LoanComponent implements OnInit {
  loan: Observable<Loan[]>=new Observable;
  constructor(private loanService: LoanService,private router: Router) { }

  ngOnInit(): void {
    this.getLoans();
  }
  getLoans()
  {
    this.loan=this.loanService.getLoans();
  }
  
}

  


