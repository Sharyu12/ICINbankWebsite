import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ChequeBook} from '../cheque-book';
import { ChequeBookService } from '../cheque-book.service';

@Component({
  selector: 'app-cheque-book-list',
  templateUrl: './cheque-book-list.component.html',
  styleUrls: ['./cheque-book-list.component.css']
})
export class ChequeBookListComponent implements OnInit {

  ChequeBook: Observable<ChequeBook[]>=new Observable;
  constructor(private ChequeBookService:ChequeBookService,private router: Router) { }

  ngOnInit(): void {
    this.getchequebook();
  }
  getchequebook()
  {
    this.ChequeBook=this.ChequeBookService.getchequebook();
  }
  
  

  chequebookDetails(u_name: string){
    this.router.navigate(['details', u_name]);
  }

}
