export class FundTransaction {
    a_no:number=0;
    date:Date=new Date;
    ta_no:number=0;
    amount:number=0; 
    t_id:number=0;
}
