import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Savingaccount } from '../savingaccount';
import { SavingaccountService } from '../savingaccount.service';

@Component({
  selector: 'app-savingaccount-list',
  templateUrl: './savingaccount-list.component.html',
  styleUrls: ['./savingaccount-list.component.css']
})
export class SavingaccountListComponent implements OnInit {
  savingaccount: Observable<Savingaccount[]>=new Observable;
  constructor(private savingaccountService: SavingaccountService,private router: Router) { }

  ngOnInit(): void {
    this.getSavingaccounts();
  }
  getSavingaccounts()
  {
    this.savingaccount=this.savingaccountService.getSavingaccounts();
  }
  savingaccountDetails(id: number){
    this.router.navigate(['savedetail', id]);
  }
}
