import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { admin } from './admin';
@Injectable({
  providedIn: 'root'
})
export class adminService {
  admin(admin: admin) {
    throw new Error('Method not implemented.');
  }
 
 
  private baseUrl = 'http://localhost:9080/api/v1';

  constructor(private http: HttpClient) { }

  getadmins(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAlladmins');
  }
  

  adminrequest(adminrequest: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/loginUser', adminrequest);
  }

  

  


}
