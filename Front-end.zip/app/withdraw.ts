export class withdraw{
    
    account_no:number=0;
    account_title:string="";
    amount:number=0;
    receiving_institution:string="";
    transaction_id:number=0;
    withdraw_date:number=0;
    
}