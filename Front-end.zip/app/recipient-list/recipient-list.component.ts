import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Recipient} from '../recipient';
import { RecipientService } from '../recipient.service';

@Component({
  selector: 'app-recipient-list',
  templateUrl: './recipient-list.component.html',
  styleUrls: ['./recipient-list.component.css']
})
export class RecipientListComponent implements OnInit {

  recipient: Observable<Recipient[]>=new Observable;
  constructor(private RecipientService:RecipientService,private router: Router) { }

  ngOnInit(): void {
    this.getrecipient();
  }
  getrecipient()
  {
    this.recipient=this.RecipientService.getrecipient();
  }
  
  

  recipientDetails(a_name: string){
    this.router.navigate(['details', a_name]);
  }

}
