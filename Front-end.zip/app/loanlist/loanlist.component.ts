import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Loan } from '../loan';
import { LoanService } from '../loan.service';

@Component({
  selector: 'app-loanlist',
  templateUrl: './loanlist.component.html',
  styleUrls: ['./loanlist.component.css']
})
export class LoanlistComponent implements OnInit {
  loan: Observable<Loan[]>=new Observable;
  constructor(private loanService: LoanService,private router: Router) { }

  ngOnInit(): void {
    this.getLoans();
  }
  getLoans()
  {
    this.loan=this.loanService.getLoans();
  }
}
