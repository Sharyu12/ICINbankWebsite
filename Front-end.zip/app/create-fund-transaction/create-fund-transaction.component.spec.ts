import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateFundTransactionComponent } from './create-fund-transaction.component';

describe('CreateFundTransactionComponent', () => {
  let component: CreateFundTransactionComponent;
  let fixture: ComponentFixture<CreateFundTransactionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateFundTransactionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateFundTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
