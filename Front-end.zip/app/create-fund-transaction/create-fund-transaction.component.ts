import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FundTransaction } from '../fund-transaction';
import { FundTransactionService } from '../fund-transaction.service';

@Component({
  selector: 'app-create-fund-transaction',
  templateUrl: './create-fund-transaction.component.html',
  styleUrls: ['./create-fund-transaction.component.css']
})
export class CreateFundTransactionComponent implements OnInit {

  fundTransaction: FundTransaction= new FundTransaction();
  submitted = false;


  constructor(private fundTransactionService: FundTransactionService, private router: Router) { }

  ngOnInit(): void {
  }
  newfundTransaction(): void {
    this.submitted = false;
    this.fundTransaction = new FundTransaction();
  }

  save() {
    this.fundTransactionService.createfundTransaction(this.fundTransaction).subscribe(data => {
      console.log(data+" "+this.fundTransaction)
     this.fundTransaction = new FundTransaction();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/fund']);
  }

}
