import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { withdraw} from '../withdraw';
import { withdrawService } from '../withdraw.service';

@Component({
  selector: 'app-withdraw-list',
  templateUrl: './withdraw-list.component.html',
  styleUrls: ['./withdraw-list.component.css']
})
export class WithdrawListComponent implements OnInit {

  withdraw: Observable<withdraw[]>=new Observable;

  constructor(private withdrawService: withdrawService,private router: Router) {}
  
  ngOnInit(): void {
    this.getwithdraw();
  }

  getwithdraw()
  {
    this.withdraw=this.withdrawService.getwithdraw();
  }
  
  

  withdrawDetails(id: number){
    this.router.navigate(['details', id]);
  }
  
}
