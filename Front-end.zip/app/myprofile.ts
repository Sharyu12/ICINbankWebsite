export class Myprofile{
    u_name: string="";
    p_no: number=0;
    name: string="";
    address: string="";
    email: string="";
    phone: number=0;
    s_no: number=0;
    status: string="";
    id: number=0;
}