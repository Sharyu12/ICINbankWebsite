import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Loanrequest } from '../loanrequest';
import { LoanrequestService } from '../loanrequest.service';
@Component({
  selector: 'app-update-loanrequest',
  templateUrl: './update-loanrequest.component.html',
  styleUrls: ['./update-loanrequest.component.css']
})
export class UpdateLoanrequestComponent implements OnInit {
  id: number=0;
  loanrequest: Loanrequest=new Loanrequest();
  constructor(private route: ActivatedRoute,private router: Router,
    private loanrequestService: LoanrequestService) { }

  ngOnInit() {this.loanrequest = new Loanrequest();

    this.id = this.route.snapshot.params['id'];
    
    this.loanrequestService.getLoanrequest(this.id)
      .subscribe(data => {
        console.log(data)
        this.loanrequest = data;
      }, error => console.log(error));
  }

  updateLoanrequest() {
    this.loanrequestService.updateLoanrequest(this.id, this.loanrequest)
      .subscribe(data => {
        console.log(data);
        this.loanrequest = new Loanrequest();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateLoanrequest();    
  }

  gotoList() {
    this.router.navigate(['/employees']);
  }
  }


