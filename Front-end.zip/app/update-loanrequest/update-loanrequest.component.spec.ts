import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateLoanrequestComponent } from './update-loanrequest.component';

describe('UpdateLoanrequestComponent', () => {
  let component: UpdateLoanrequestComponent;
  let fixture: ComponentFixture<UpdateLoanrequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateLoanrequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateLoanrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
