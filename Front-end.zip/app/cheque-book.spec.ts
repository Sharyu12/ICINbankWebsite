import { ChequeBook } from './cheque-book';

describe('ChequeBook', () => {
  it('should create an instance', () => {
    expect(new ChequeBook()).toBeTruthy();
  });
});
